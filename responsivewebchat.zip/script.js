
const quizData = [
  {
    question: "What is the capital of France?",
    options: ["Berlin", "Paris", "Rome", "Madrid"],
    correctAnswer: "Paris"
  },
];

let currentQuestion = 0;
let score = 0;
let timeRemaining = 60; 
let timerInterval;

const questionElement = document.getElementById("question");
const answerButtons = document.querySelectorAll(".answer");
const timerElement = document.getElementById("timer");
const feedbackElement = document.getElementById("feedback");
const startQuizButton = document.getElementById("start-quiz");
const showLeaderboardButton = document.getElementById("show-leaderboard");
const leaderboardElement = document.getElementById("leaderboard");
const leaderboardList = document.getElementById("leaderboard-list");

function displayQuestion() {
  const question = quizData[currentQuestion];
  questionElement.textContent = question.question;
  for (let i = 0; i < answerButtons.length; i++) {
    answerButtons[i].textContent = question.options[i];
    answerButtons[i].onclick = () => checkAnswer(question.options[i]);
  }
}
function checkAnswer(selectedAnswer) {
  const correctAnswer = quizData[currentQuestion].correctAnswer;
  if (selectedAnswer === correctAnswer) {
    score++;
    feedbackElement.textContent = "Correct!";
  } else {
    feedbackElement.textContent = "Incorrect!";
  }
  currentQuestion++;
  if (currentQuestion < quizData.length) {
    displayQuestion();
  } else {
    endQuiz();
  }
}
function startQuiz() {
  startQuizButton.style.display = "none";
  showLeaderboardButton.style.display = "none";
  displayQuestion();
  startTimer();
}
function startTimer() {
  timerInterval = setInterval(() => {
    timeRemaining--;
    timerElement.textContent = formatTime(timeRemaining);
    if (timeRemaining <= 0) {
      clearInterval(timerInterval);
      endQuiz();
    }
  }, 1000);
}
function formatTime(seconds) {
  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = seconds % 60;
  return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
}
function endQuiz() {
  clearInterval(timerInterval);
  feedbackElement.textContent = `Quiz finished! Your score is ${score} out of ${quizData.length}`;
  showLeaderboardButton.style.display = "block"; 
  updateLeaderboard();
}
function updateLeaderboard() {
  let leaderboard = JSON.parse(localStorage.getItem("leaderboard")) || [];
  leaderboard.push({ score: score, name: prompt("Enter your name:") });
  leaderboard.sort((a, b) => b.score - a.score);
  localStorage.setItem("leaderboard", JSON.stringify(leaderboard));
  displayLeaderboard();
}
function displayLeaderboard() {
  leaderboardList.innerHTML = "";
  const leaderboard = JSON.parse(localStorage.getItem("leaderboard")) || [];
  leaderboard.forEach((entry, index) => {
    const listItem = document.createElement("li");
    listItem.textContent = `${index + 1}. ${entry.name}: ${entry.score}`;
    leaderboardList.appendChild(listItem);
  });
}
startQuizButton.addEventListener("click", startQuiz);
showLeaderboardButton.addEventListener("click", () => {
  leaderboardElement.style.display = "block";
  displayLeaderboard();
});